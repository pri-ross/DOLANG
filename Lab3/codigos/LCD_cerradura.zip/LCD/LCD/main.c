#define F_CPU    16000000UL
#define PCF8574  0x27 // Direcci�n I2C del LCD

#include <xc.h>
#include <avr/io.h>
#include <util/twi.h>
#include <util/delay.h>
#include <string.h> // Incluye la biblioteca para strcmp y memset
#include "twi_lcd.h"

// Definici�n del teclado 3x3 (debe estar tambi�n en twi_lcd.h)
char keypad[3][3] = {
	{'1', '2', '3'},
	{'4', '5', '6'},
	{'7', '8', '9'}
};

// Pines de LEDs y buzzer
#define GREEN_LED_PIN   PD3
#define RED_LED_PIN     PD2
#define BUZZER_PIN      PB3

// EEPROM Address for storing password
#define EEPROM_ADDR 0

// Variables
char password[6] = "1234"; // Contrase�a por defecto
char input[6];  // Entrada del usuario
char new_password[6];  // Nueva clave para el cambio
uint8_t attempt_count = 0;
uint8_t input_len = 0;
uint8_t change_mode = 0;  // Modo de cambio de clave

// Funci�n de inicializaci�n de UART
void UART_init(uint16_t ubrr) {
	UBRR0H = (unsigned char)(ubrr >> 8);
	UBRR0L = (unsigned char)ubrr;
	UCSR0B = (1 << RXEN0) | (1 << TXEN0);
	UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);
}

// Funci�n para enviar un car�cter por UART
void UART_sendChar(char c) {
	while (!(UCSR0A & (1 << UDRE0)));
	UDR0 = c;
}

// Inicializaci�n del teclado
void keypad_init() {
	DDRB |= 0x07;  // Configura las filas (0, 1, 2) como salidas
	DDRD &= ~(0xE0);  // Configura las columnas (5, 6, 7) como entradas
	PORTD |= 0xE0;  // Habilita las resistencias pull-up en las columnas
}

// Lee las teclas del teclado
char read_keypad(void) {
	for (int8_t row = 2; row >= 0; row--) {
		PORTB = ~(1 << row);
		for (uint8_t col = 0; col < 3; col++) {
			if (!(PIND & (1 << (col + 5)))) {
				_delay_ms(50);
				while (!(PIND & (1 << (col + 5))));
				return keypad[row][col];
			}
		}
	}
	return 0;  // Si no se presion� ninguna tecla, retorna 0
}

// Funci�n para verificar la contrase�a
void check_password() {
	if (strcmp(input, password) == 0) {
		twi_lcd_clear();
		twi_lcd_msg(" correcta");
		PORTD |= (1 << GREEN_LED_PIN);  // Enciende la luz verde
		_delay_ms(2000);  // Mantiene la luz verde encendida por 2 segundos
		PORTD &= ~(1 << GREEN_LED_PIN);  // Apaga la luz verde
		twi_lcd_clear();  // Borra mensaje
		attempt_count = 0;  // Reinicia el contador de intentos
		
		// Pregunta si desea- cambiar la clave
		twi_lcd_msg("_ cambiar clave?");
		twi_lcd_cmd(0xC0);  // Mueve el cursor a la segunda l�nea
		twi_lcd_msg(" 1:SI, 2:NO ");
		change_mode = 1;  // Permite seleccionar opci�n de cambio de clave
		
		} else {
		twi_lcd_clear();
		twi_lcd_msg("____ clave_incorrecta");
		PORTD |= (1 << RED_LED_PIN);  // Enciende la luz roja
		_delay_ms(2000);  // Mantiene la luz roja encendida por 2 segundos
		PORTD &= ~(1 << RED_LED_PIN);  // Apaga la luz roja
		twi_lcd_clear();  // Borra mensaje
		attempt_count++;

	if (attempt_count >= 3) {  // Si se alcanzan 3 intentos fallidos
		twi_lcd_clear();
		twi_lcd_msg("__ Alarma activada");

		// Genera el tono sinusoidal para la alarma
		for (int i = 0; i < 1; i++) {  // Repite el tono de alarma 5 veces
			generateSinusoidalTone();  // Aplica la variaci�n sinusoidal
			_delay_ms(200);
		}

		_delay_ms(3000);  // Tiempo extra con la alarma activada
		PORTB &= ~(1 << BUZZER_PIN);  // Apaga el buzzer
		twi_lcd_clear();  // Borra mensaje
		attempt_count = 0;  // Reinicia el contador de intentos


		}
	}
	input_len = 0;  // Reinicia el �ndice de entrada
	memset(input, 0, sizeof(input));  // Limpia la entrada
}

// Funci�n para confirmar y cambiar la clave
void confirm_new_password() {
	if (strcmp(input, new_password) == 0) {
		strcpy(password, new_password);  // Actualiza la clave
		twi_lcd_clear();
		twi_lcd_msg("clave_actualizada");
		twi_lcd_msg("__  actualizada!");
		_delay_ms(2000);
		twi_lcd_clear();  // Borra el mensaje
		} else {
		twi_lcd_clear();
		twi_lcd_msg("__ no coinciden");
		_delay_ms(2000);
		twi_lcd_clear();  // Borra el mensaje
	}
	change_mode = 0;  // Sale del modo de cambio de clave
	input_len = 0;
}
void generateTone(uint16_t frequency) {
	if (frequency > 0) {
		uint16_t delayPeriod = 1000000 / frequency; // Ajusta el per�odo de delay para una frecuencia m�s fuerte
		for (uint16_t i = 0; i < 100; i++) {       // Aumenta la duraci�n del sonido
			PORTB |= (1 << BUZZER_PIN);            // Activa el buzzer
			for (uint16_t j = 0; j < (delayPeriod / 2); j++) {
				_delay_us(1);  // Retardo para la mitad del ciclo
			}
			PORTB &= ~(1 << BUZZER_PIN);           // Desactiva el buzzer
			for (uint16_t j = 0; j < (delayPeriod / 2); j++) {
				_delay_us(1);  // Retardo para la segunda mitad del ciclo
			}
		}
	}
}
void generateSinusoidalTone(void) {
	float sinVal;
	int toneVal;

	// Ciclo para generar un tono con variaci�n sinusoidal
	for (int x = 0; x < 180; x++) {
		sinVal = sin(x * (M_PI / 180.0));           // Calcula el valor sinusoidal
		toneVal = 2000 + (int)(sinVal * 1000);      // Ajusta la frecuencia base (2000 Hz) con la variaci�n sinusoidal
		generateTone(toneVal);                      // Genera el tono con la frecuencia modulada
		_delay_ms(2);                               // Peque�o retardo para la variaci�n
	}
}


// Funci�n principal
int main(void) {
	twi_init();  // Inicializa la comunicaci�n I2C
	twi_lcd_init();  // Inicializa la LCD
	twi_lcd_cmd(0x80);  // Posiciona el cursor en la primera l�nea
	twi_lcd_clear();  // Limpia la pantalla
	keypad_init();  // Inicializa el teclado
	UART_init(103);

	// Configura los pines de los LEDs y el buzzer
	DDRD |= (1 << GREEN_LED_PIN) | (1 << RED_LED_PIN); // Configura pines D4 y D3 como salidas
	DDRB |= (1 << BUZZER_PIN); // Configura pin B3 como salida
 PORTB &= ~(1 << BUZZER_PIN);  // Asegura que el buzzer est� apagado al iniciar

	char key;  // Variable para almacenar la tecla presionada
	
	while (1) {
		key = read_keypad();  // Lee la tecla presionada

		if (key) {  // Si se ha presionado una tecla
			if (change_mode == 1 && key == '1') {  // Inicia el modo de cambio de clave si se presiona '1'
				twi_lcd_clear();
				twi_lcd_msg(" Cambiar clave");
				_delay_ms(2000);
				twi_lcd_clear();
				change_mode = 2;  // Cambia a modo de ingreso de nueva clave
				input_len = 0;
				} else if (change_mode == 1 && key == '2') {
				change_mode = 0;  // Cancela el cambio de clave
				twi_lcd_clear();
				} else if (input_len < 4) {
				input[input_len++] = key;  // Agrega el car�cter de la tecla a la entrada
				twi_lcd_dwr('*');  // Muestra * en lugar de la tecla
				UART_sendChar(key);
				UART_sendChar('\n');
			}

			if (input_len == 4) {  // Si se ingresaron 4 caracteres
				if (change_mode == 0) {
					check_password();  // Verifica la contrase�a
					} else if (change_mode == 3) {
					confirm_new_password();  // Confirma la nueva clave
					} else if (change_mode == 2) {
					strcpy(new_password, input);  // Guarda la nueva clave temporal
					twi_lcd_clear();
					twi_lcd_msg(" Confirme clave:");
					input_len = 0;
					change_mode = 3;  // Cambia a modo de confirmaci�n
				}
				_delay_ms(500);
			}
			_delay_ms(200);  // Retardo para evitar m�ltiples lecturas por un solo toque
		}
	}
}
