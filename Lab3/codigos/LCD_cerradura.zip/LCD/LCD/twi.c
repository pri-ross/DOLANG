#include <avr/io.h>
#include "twi.h"

void twi_init()
{
	DDRC = 0x03;
	PORTC = 0x03;
	
	TWCR &= ~(1<<TWEN);
	TWBR = BITRATE(TWSR = 0x00);
	TWCR = (1<<TWEN);
	_delay_us(10);
}

void twi_start()
{
	TWCR= (1<<TWINT)|(1<<TWSTA)|(1<<TWEN);
	while(!(TWCR & (1<<TWINT)));
	while(TW_STATUS != TW_START);
}

void twi_write_cmd(unsigned char address)
{
	TWDR=address;
	TWCR=(1<<TWINT)|(1<<TWEN);
	while (!(TWCR & (1<<TWINT)));
	while(TW_STATUS != TW_MT_SLA_ACK);
}

void twi_write_dwr(unsigned char data)
{
	TWDR=data;
	TWCR=(1<<TWINT)|(1<<TWEN);
	while (!(TWCR & (1<<TWINT)));
	while(TW_STATUS != TW_MT_DATA_ACK);
}

void twi_stop()
{
	TWCR = (1<<TWINT)|(1<<TWEN)|(1<<TWSTO);
}

void twi_repeated_start()
{
	TWCR= (1<<TWINT)|(1<<TWSTA)|(1<<TWEN);
	while(!(TWCR & (1<<TWINT)));
	while(TW_STATUS != TW_REP_START);
}

char twi_read_ack()
{
	TWCR=(1<<TWEN)|(1<<TWINT)|(1<<TWEA);
	while (!(TWCR & (1<<TWINT)));
	while(TW_STATUS != TW_MR_DATA_ACK);
	return TWDR;
}

char twi_read_nack()
{
	TWCR=(1<<TWEN)|(1<<TWINT);
	while (!(TWCR & (1<<TWINT)));
	while(TW_STATUS != TW_MR_DATA_NACK);
	return TWDR;
}

void twi_lcd_data(unsigned char data)
{
	unsigned char lcd_data = 0x09;
	lcd_data |= (data & 0xF0);

	PCF8574_write(lcd_data);
	_delay_us(2);
	lcd_data &= ~(0x04);
	PCF8574_write(lcd_data);
	_delay_us(5);

	lcd_data |= ((data & 0x0F) << 4);
	lcd_data |= 0x04;
	PCF8574_write(lcd_data);
	_delay_us(2);
	lcd_data &= ~(0x04);
	PCF8574_write(lcd_data);
	_delay_us(5);
}
